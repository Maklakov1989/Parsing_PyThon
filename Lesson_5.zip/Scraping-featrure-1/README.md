# Scraping

Cute ♥ project based on scrapy framework
